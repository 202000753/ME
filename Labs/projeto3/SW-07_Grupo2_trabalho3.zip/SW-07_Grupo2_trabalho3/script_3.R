################################################################################################## 
##                                                                                              ##
##                               PREPARING THE WORKSPACE                                        ##
##                                                                                              ##
##################################################################################################


## OBS: CHANGE PATH##
setwd("C:/Users/nunor/Downloads/SW-07_Grupo2_trabalho3")
getwd()


## READING DATASET ##
library(readxl)
dfMain<-read_excel("Korea Income and Welfare.xlsx") 


## GENERAL SAMPLE INFO ##

##dfMain general data info##
dim(dfMain)## 92857    14
str(dfMain)
summary(dfMain)## NA's   :33643 +   NA's   :33642  + NA's   :60710  
head(dfMain)
tail(dfMain)

################################################################################################## 
##                                                                                              ##
##                               CLEANING THE SAMPLE DATA                                       ##
##                                                                                              ##
##################################################################################################


###VARIABLE occupation(REPLACE THE 'NA' WITH 0, WE HAVE NO KNOWLEDGE OF WHAT THE OCCUPATION OF THE SUBJECT OF THIS OBSERVATION IS)
dfMain$occupation[is.na(dfMain$occupation)]<-0
range(dfMain$occupation)
unique(dfMain$occupation)
dfMain$occupation[dfMain$occupation == 9999]<-999 ##remove outlier
range(dfMain$occupation)

##VARIABLE company_size(REPLACE THE 'NA' WITH 0, WE HAVE NO KNOWLEDGE OF WHAT THE COMPANY SIZE OF THE SUBJECT OF THIS OBSERVATION IS)
dfMain$company_size[is.na(dfMain$company_size)]<-0
dfMain$company_size[dfMain$company_size >= 20]<-0
range(dfMain$company_size)
unique(dfMain$company_size)

##VARIABLE reason_none_worker(REPLACE THE 'NA' and the '99' WITH 0, WE HAVE NO KNOWLEDGE OF WHAT THE NONE WORKER REASON OF THE SUBJECT OF THIS OBSERVATION IS)  
dfMain$reason_none_worker[is.na(dfMain$reason_none_worker)]<-0
dfMain$reason_none_worker[dfMain$reason_none_worker == 99]<-0
range(dfMain$reason_none_worker)
unique(dfMain$reason_none_worker)

dim(dfMain) 

################################################################################################## 
##                                                                                              ##
##                   CHARACTERIZATION OF THE SELECTED VARIABLES                                 ##
##                                                                                              ##
##################################################################################################

########################################VARIABLE year_born########################################
 
#year_born->X->� o ano de nascimento dos individuos observados no presente estudo

# Regra Sturges
(n1 <- length(dfMain$year_born)) # n = dimens�o da amostra

(k1<-trunc(1+log(n1)/log(2)))# k = n�mero de classes = n�mero de linhas da tabela

# amplitude de cada classe = h
(A1 = range(dfMain$year_born)[2]-range(dfMain$year_born)[1])
(h1<-A1/k1)

max(dfMain$year_born)

#limites das classes
(cortes <- seq(min(dfMain$year_born), max(dfMain$year_born), by=h1))

#definir as classes -> cut()
# classes fechadas � direita -> ] , ] = ( , ]
(classes <- cut(dfMain$year_born, breaks=cortes, right=TRUE,
                include.lowest=TRUE))

# frequ�ncias absolutas
(ni1<-table(classes))
# nomes das classes
(nclasses1 <- rownames(ni1))
# frequ�ncias relativas
(fi1<-ni1/n1)
#frequ�ncias absolutas acumuladas
(Ni1<-cumsum(ni1))
#frequ�ncias relativas acumuladas
(Fi1<-Ni1/n1)

(tab.frq1 <- data.frame(classes = nclasses1,
                       ni=as.integer(ni1),
                       fi=round(as.numeric(fi1),4),
                       Ni=as.integer(Ni1),
                       Fi=round(as.numeric(Fi1),4)))

#GRAPHIC REPRESENTATION(REPRESENTA��O GR�FICA DOS DADOS)

# Histograma

(histCortes <- cortes) 

hist(dfMain$year_born, breaks=histCortes,
     main="Histograma do ano de nascimento",
     xlab="Ano de nascimento",
     ylab="Frequ�ncias absolutas",
     col="gold",
     xlim=c(1900,2010),  
     ylim=c(0,15000))


## Caixa de Bigodes
boxplot(dfMain$year_born, range=1.5)



#NUMERICAL LOCATION AND DISPERSION INDICATORS(INDICADORES NUM�RICOS DE LOCALIZA��O E DISPERS�O)

# medidas de localiza��o central: m�dia, mediana e moda

#MODA
if( range(table(dfMain$year_born))[1]==range(table(dfMain$year_born))[2]){
  print("amodal")
} else{
  print(paste("Moda:",DescTools::Mode(dfMain$year_born)))
}

mean(dfMain$year_born)#MEDIA

median(dfMain$year_born)#MEDIANA

#medidas de localizacao n�o central: Quantis (Quartis e Decis)

quantile(dfMain$year_born, c(0.25,0.50,0.75))#QUARTIS

quantile(dfMain$year_born, probs = seq(.1, .9, by = .1))#DECIS

# medidas de dispers�o: vari�ncia, desvio padr�o, amplitude total, amplitude interquartil 

var(dfMain$year_born) #VARI�NCIA

sd(dfMain$year_born) #DESVIO PADR�O

(A = max(dfMain$year_born)-min(dfMain$year_born))#AMPLITUDE TOTAL

(AIQ = IQR(dfMain$year_born))#AMPLITUDE INTERQUARTIL

##Assimetria

library(e1071)
skewness(dfMain$year_born,type=3)
##Assimetria positiva* dado que b1>0

## Curtose

kurtosis(dfMain$year_born,type = 3)
## Curva Platic�rtica* ou achatada dado que b2<0

#######################################################################################
#######################################################################################

#             teste de ajustamento de Qui Quadrado

#######################################################################################
#######################################################################################
# O histograma indica uma distribui��o aproximadamente Normal

# H0:X segue uma distribui��o Normal
# contra
# H1:X N�O segue uma distribui��o Normal



# frequ�ncias absolutas = frequ�ncias Observadas
(Oi<-table(classes))


# � necess�rio estimar o theta -> m�dia amostral
(elx <- mean(dfMain$year_born))

r <- 1  # estimou-se um par�metro
(gl <- k1-1-r)  # graus de liberdade da distribui��o Qui-Quadrado

# probabilidades necess�rias para as frequ�ncias esperadas
(pi =pnorm(cortes[2:(k1+1)],1/elx))
for(i in 2:k1){
  pi[i] <- pnorm(cortes[i+1],1/elx)-pnorm(cortes[i],1/elx)
} 
pi[k1] <- 1-pnorm(cortes[k1],1/elx)
pi
sum(pi)

#teste de ajustamento do Qui-Quadrado -> neste caso todos os resultados N�O est�o certos pois r=1
chisq.test(Oi,p=pi)
# os graus de liberdade e o valor-p est�o errados pois n�o tem em considera��o 
# que os par�metros tiveram de ser estimados (r=1)

testdata.1 <- chisq.test(Oi,p=pi)

testdata.1$statistic # Qobs
testdata.1$parameter # graus de liberdade -> errado
testdata.1$p.value  # valor-p -> errado
testdata.1$observed  # Oi
testdata.1$expected # Ei=npi

# valor-p correto
valorp <- 1-pchisq(testdata.1$statistic[[1]],gl)
valorp

############################

# verificar as regras recomendadas
data.frame(O=testdata.1$observed,
           E=testdata.1$expected,
           row.names = NULL)
n1

# dimens�o da amostra maior que 30
if(n1>30){
  print("respeita a regra")
}else{
  print("a amostra � pequena")
}

# todas as frequ�ncias Esperadas >= 1
if(length(which(testdata.1$expected<1))>0){
  print("juntar linhas da tabela de frequ�ncias")
}else{
  print("respeita a regra")
}

# n�o h� mais de 20% das frequ�ncias Esperadas < 17
if(length(which(testdata.1$expected<17))>(k1*0.0588)){
  print("juntar linhas da tabela de frequ�ncias")
}else{
  print("respeita a regra")
}

# juntar linhas, as quatro �ltimas linhas (s�o as que t�m as frequ�ncias que n�o respeitam uma das regras)

# perde 15 linhas
k2 <- k1-15

(gl2 <- k2-1-r)


#limites das classes
(cortes2<- c(cortes[1:k2],cortes[k1+1]))

#definir as classes -> cut()
(classes2 <- cut(dfMain$year_born, breaks=cortes2, right=TRUE, 
                 include.lowest=TRUE, dig.lab = 5))

# frequ�ncias absolutas = frequ�ncias Observadas
(Oi2<-table(classes2))

# probabilidades necess�rias para as frequ�ncias esperadas
# probabilidades necess�rias para as frequ�ncias esperadas
(pi2 =pnorm(cortes2[2:(k2+1)],1/elx))
for(i in 2:k2){
  pi2[i] <- pnorm(cortes2[i+1],1/elx)-pnorm(cortes2[i],1/elx)
} 
pi2[k2] <- 1-pnorm(cortes2[k2],1/elx)
pi2
sum(pi2)

#teste de ajustamento do Qui-Quadrado -> neste caso todos os resultados N�O est�o certos pois r=1
chisq.test(Oi2,p=pi2)
# os graus de liberdade e o valor-p est�o errados pois n�o tem em considera��o 
# que os par�metros tiveram de ser estimados (r=1)

datatest.2 <- chisq.test(Oi2,p=pi2)

datatest.2$statistic # Qobs
datatest.2$parameter # graus de liberdade -> errado
datatest.2$p.value  # valor-p -> errado
datatest.2$observed  # Oi
datatest.2$expected # Ei=npi

# valor-p correto
valorp2 <- 1-pchisq(datatest.2$statistic[[1]],gl2)
valorp2

############################

# verificar as regras recomendadas

data.frame(O=datatest.2$observed,
           E=datatest.2$expected,
           row.names = NULL)

# n�o h� mais de 20% das frequ�ncias Esperadas < 5
if(length(which(datatest.2$expected<5))>(k2*0.2)){
  print("juntar linhas da tabela de frequ�ncias")
}else{
  print("respeita a regra")
}

#################

#tabela que estamos a comparar
data.frame(O=datatest.2$observed,
           E=datatest.2$expected,
           row.names = NULL)

#graficamente o que estamos a comparar

hist(dfMain$year_born, breaks=cortes2, freq=FALSE, col="red", main="",xaxt="n")  # histograma dos dados observados
axis(side=1, at=cortes2)
curve(dnorm(x, rate=1/elx), from=min(dfMain$year_born), col="green",lwd=4, add=TRUE) # fun��o densidade de probabilidade da distribui��o normal
legend("topright", 
       legend=c("observado", "esperado"), 
       fill=c("red", NA),
       border=c("black",NA),
       lty=c(NA,1),lwd=c(NA,4),
       col=c(NA, "green"),
       x.intersp = c(0.01,1))


############################

#####################
# tomar uma decis�o #
#####################


alpha <- 0.10
valorp2 #0
# a partir do valor-p N�O se Rejeita H0
# pois Rejeita-se H0 se alpha >= valor_p


################################################################################################## 
##                                                                                              ##
##                   CHARACTERIZATION OF THE SELECTED VARIABLES                                 ##
##                                                                                              ##
##################################################################################################

########################################VARIABLE company_size#####################################  

##REMOVE VALUE 0 , SO IT WONT LEAD TO WRONG CONCLUSIONS
temp<-dfMain$company_size[which(dfMain$company_size<99)]
temp2 <- as.numeric(temp)
dfCompany_size<-temp2[which(temp2!=0)]
## SEE NEW DATA
summary(dfCompany_size)
unique(dfCompany_size)



#FREQUENCY TABLE(TABELA DE FREQUENCIAS)
(ni2 <- table(dfCompany_size))#frequ�ncias absolutas
(xi2 <- rownames(ni2))#n�veis da vari�vel

(n2 <- length(dfCompany_size))#n = dimens�o da amostra

(fi2 <- ni2/n2)#frequ�ncias relativas

(Ni2 <- cumsum(ni2))# frequ�ncias absolutas acumuladas
(Fi2 <- cumsum(fi2))#frequ�ncias relativas acumuladas

# tabela de frequ�ncias como uma data.frame
(tab.freq2 <- data.frame(i=1:nrow(ni),       # n�mero da linha
                        xi =xi,             # n�veis da vari�vel
                        ni=as.integer(ni),  # frequ�ncias absolutas
                        fi=as.numeric(fi),  # frequ�ncias relativas
                        Ni=as.integer(Ni),  # frequ�ncias absolutas acumuladas
                        Fi=as.numeric(Fi))) # frequ�ncias relativas acumuladas


#GRAPHIC REPRESENTATION(REPRESENTA��O GR�FICA DOS DADOS)

# Gr�fico de Barras
barplot(ni, names.arg=xi, ylim=c(0,30000), 
        ylab="FREQUENCIAS ABSOLUTAS", xlab="NR DE EMPREGADOS/TAMANHO DA EMPRESA",
        main="Tamanho da Empresa", 
        col=c("blue"))
box(bty = "L")

# Gr�fico Circular
pie(ni, labels=paste(xi,("->"),round(fi*100), "%"), 
    col=c("red", "yellow", "blue", "green"),
    main="Gr�fico Circular: TAMANHO DA EMPRESA")
legend("topleft", legend=c(xi), 
       fill=c("red", "yellow", "blue", "green"), cex = 0.75)

## Caixa de Bigodes
boxplot(dfCompany_size, range=1.5, col = 3)



#NUMERICAL LOCATION AND DISPERSION INDICATORS(INDICADORES NUM�RICOS DE LOCALIZA��O E DISPERS�O)
# medidas de localiza��o central: m�dia, mediana e moda
#MODA
tab.freq[which(tab.freq$ni==max(tab.freq$ni)),2]

mean(dfCompany_size)#MEDIA

median(dfCompany_size)#MEDIANA

#medidas de localizacao n�o central: Quantis (Quartis e Decis)

quantile(dfCompany_size, c(0.25,0.50,0.75))#QUARTIS

quantile(dfCompany_size, probs = seq(.1, .9, by = .1))#DECIS

# medidas de dispers�o: vari�ncia, desvio padr�o, amplitude total, amplitude interquartil 

var(dfCompany_size) #VARI�NCIA

sd(dfCompany_size) #DESVIO PADR�O

(A = max(dfCompany_size)-min(dfCompany_size))#AMPLITUDE TOTAL

(AIQ = IQR(dfCompany_size))#AMPLITUDE INTERQUARTIL

##ASSIMETRIA

skewness(dfCompany_size,type=3)
##Assimetria positiva dado que b1>0

## Curtose

kurtosis(dfCompany_size,type = 3)
## curva leptoc�rtica, alongada dado que b2>0



########################################VARIABLE year_born########################################

##CHARACTERIZATION OF VARIABLE year_born has been done previously




#######################################################
#######################################################
##                Regress�o Linear

# vari�veis: 
# X - company_size
# Y - year_born

(amostra <- data.frame(x=dfMain$company_size, 
                       y=dfMain$year_born))
##################################################

# analisar a rela��o linear entre as vari�veis:
# diagrama de dispers�o -> plot()
# coeficiente de correla��o linear de Pearson -> cor()

##################################################

plot(x=amostra$x, y=amostra$y,
     pch=20, 
     xlab="Tamanho da empresa", 
     ylab="Ano de nascimento",
     main="Diagrama de Dispers�o")

##################################################


# coeficiente de correla��o linear de Pearson -> cor()

cor(x=amostra$x, y=amostra$y)

##Este foi o valor (0.5082532) mais elevado de coeficiente de correla��o linear de Pearson(n�o � apropriado o modelo)
##########################################################################################
##################################################


# pela an�lise do diagrama de dispers�o n�o se v�-se uma rela��o linear entre as vari�veis
# pois n�o � poss�vel imaginar uma reta nem com declive negativo nem com declive positivo a passar pela nuvem de pontos


# rxy= 0.5082532  -> o coeficiente confirma o que vimos no diagrama de dispers�o, a correla��o linear � muito fraca, 
# n�o se encontra entre -1<rxy<-0.8 nem entre 0.8<rxy<1.
# Seria a melhor op��o abandonar este modelo, contudo no �mbito deste trabalho vamos mant�-lo



###########################################################################################
###########################################################################################


# reta de regress�o linear  -> lm()
# vari�vel independente -> company_size = X
# vari�vel dependente -> year_born = Y

# modelo pretendido � y^=a+bx
# formula:  y~x

(modelo <- lm(formula = y~x, data=amostra))

modelo$coefficients
(a1 <- modelo$coefficients[[1]])
(b1 <- modelo$coefficients[[2]])

# ver a reta y^=a+bx no diagrama de dispers�o
plot(x=amostra$x, y=amostra$y,
     pch=20, col="blue",
     xlab="Tamanho da companhia", 
     ylab="Ano de Nascimento",
     main="Diagrama de Dispers�o")
abline(a=a1,b=b1, col="red")

##################################################

##################################################

# res�duos

modelo$residuals

# ou
# res�duos = valores observados - valores estimados = y -y^

# valores observados:
amostra$y

# valores estimados
modelo$fitted.values

# res�duos
(residuos <- amostra$y - modelo$fitted.values)

# gr�fio dos res�duos

# na regress�o linear simples � indiferente fazer a an�lise dos res�duos 
# com o diagrama de dispers�o entre a vari�vel x e os res�duous
# ou 
# com o diagrama de dispers�o entre os valores estimados do y (y^) e os res�duous
# os gr�ficos n�o s�o iguais mas as conclus�es s�o equivalentes

# gr�fico dos res�duos -> (x,e)
plot(x=amostra$x, y=modelo$residuals,
     xlab="Tamanho da Companhia",
     ylab="res�duos",
     main="Gr�fico dos res�duos")
abline(h=0, col="red")




#######################################################################################
#######################################################################################

#             teste de ajustamento de Kolmogorov-Smirnov para a regress�o linear

#######################################################################################
#######################################################################################





################################################################################################## 
##                                                                                              ##
##                   CHARACTERIZATION OF THE SELECTED VARIABLES                                 ##
##                                                                                              ##
##################################################################################################

########################################VARIABLE year############################################# 

#FREQUENCY TABLE(TABELA DE FREQUENCIAS)
(ni <- table(dfMain$year)) #frequ�ncias absolutas

(xi <- rownames(ni)) #n�veis da vari�vel

(n <- sum(ni))#n = dimens�o da amostra

(fi <- ni/n)#frequ�ncias relativas

(Ni <- cumsum(ni))# frequ�ncias absolutas acumuladas

(Fi <- cumsum(fi))#frequ�ncias relativas acumuladas

# tabela de frequ�ncias como uma data.frame

# usar as fun��es: as.integer() e as.numeric()
# para os elementos deixarem de ser do tipo "table" e passarem a ser n�meros

(tab.freq <- data.frame(i=1:nrow(ni),       # n�mero da linha
                        xi =xi,             # n�veis da vari�vel
                        ni=as.integer(ni),  # frequ�ncias absolutas
                        fi=as.numeric(fi),  # frequ�ncias relativas
                        Ni=as.integer(Ni),  # frequ�ncias absolutas acumuladas
                        Fi=as.numeric(Fi))) # frequ�ncias relativas acumuladas


#GRAPHIC REPRESENTATION(REPRESENTA��O GR�FICA DOS DADOS)


colours<-rainbow(14) # Cria 14 cores diferentes para serem utilizadas nas representa��es gr�ficas

# Gr�fico de Barras

barplot(ni, names.arg=xi, ylim=c(0,8000), 
        ylab="Frequ�ncias Absolutas", xlab="Ano do Estudo",
        main="Gr�fico de Barras:
        Ano em que o estudo foi conduzido", 
        col=colours)
box(bty = "L")

boxplot(dfMain$year, range=1.5, col=14)

# Gr�fico Circular

pie(ni, labels=paste(xi,"-",round(fi*100), "%"), 
    col=colours,
    main="Gr�fico Circular: Ano do Estudo")
legend("topleft", legend=c(xi), 
       fill=colours, cex = 0.55)

#NUMERICAL LOCATION AND DISPERSION INDICATORS(INDICADORES NUM�RICOS DE LOCALIZA��O E DISPERS�O)

# medidas de localiza��o central: m�dia, mediana e moda

#MODA
if( range(table(dfMain$year))[1]==range(table(dfMain$year))[2]){
  print("amodal")
} else{
  print(paste("Moda:",DescTools::Mode(dfMain$year)))
}

mean(dfMain$year)#MEDIA

median(dfMain$year)#MEDIANA

#medidas de localizacao n�o central: Quantis (Quartis e Decis)

quantile(dfMain$year, c(0.25,0.50,0.75))#QUARTIS

quantile(dfMain$year, probs = seq(.1, .9, by = .1))#DECIS

# medidas de dispers�o: vari�ncia, desvio padr�o, amplitude total, amplitude interquartil 

var(dfMain$year) #VARI�NCIA

sd(dfMain$year) #DESVIO PADR�O

(A = max(dfMain$year)-min(dfMain$year))#AMPLITUDE TOTAL

(AIQ = IQR(dfMain$year))#AMPLITUDE INTERQUARTIL

##Assimetria

library(e1071)
skewness(dfMain$year,type=3)
##Assimetria Negativa* dado que b1<0 (-0.03954851)

## Curtose

kurtosis(dfMain$year,type = 3)
## Curva Platic�rtica* ou achatada dado que b2<0 (-1.182807)


########################################VARIABLE family_member####################################  
  

range(dfMain$family_member)
#FREQUENCY TABLE(TABELA DE FREQUENCIAS)
(ni <- table(dfMain$family_member)) #frequ�ncias absolutas

(xi <- rownames(ni)) #n�veis da vari�vel

(n <- sum(ni))#n = dimens�o da amostra

(fi <- ni/n)#frequ�ncias relativas

(Ni <- cumsum(ni))# frequ�ncias absolutas acumuladas

(Fi <- cumsum(fi))#frequ�ncias relativas acumuladas

# tabela de frequ�ncias como uma data.frame

# usar as fun��es: as.integer() e as.numeric()
# para os elementos deixarem de ser do tipo "table" e passarem a ser n�meros

(tab.freq <- data.frame(i=1:nrow(ni),       # n�mero da linha
                        xi =xi,             # n�veis da vari�vel
                        ni=as.integer(ni),  # frequ�ncias absolutas
                        fi=as.numeric(fi),  # frequ�ncias relativas
                        Ni=as.integer(Ni),  # frequ�ncias absolutas acumuladas
                        Fi=as.numeric(Fi))) # frequ�ncias relativas acumuladas


#GRAPHIC REPRESENTATION(REPRESENTA��O GR�FICA DOS DADOS)


colours<-rainbow(9) # Cria 9 cores diferentes para serem utilizadas nas representa��es gr�ficas

# Gr�fico de Barras

barplot(ni, names.arg=xi, ylim=c(0,30000), 
        ylab="Frequ�ncias Absolutas", xlab="Numero de Elementos da Familia",
        main="Gr�fico de Barras:
        Extens�o do Agregado familiar", 
        col=colours)
box(bty = "L")

boxplot(dfMain$family_member, range=1.5)

# Gr�fico Circular

pie(ni, labels=paste(xi, "Elementos - ", round(fi*100), "%"), 
    col=colours,
    main="Gr�fico Circular: Agregado Familiar")
legend("bottomleft", legend=c(xi), 
       fill=colours, cex = 0.75)

#NUMERICAL LOCATION AND DISPERSION INDICATORS(INDICADORES NUM�RICOS DE LOCALIZA��O E DISPERS�O)

# medidas de localiza��o central: m�dia, mediana e moda

#MODA
if( range(table(dfMain$family_member))[1]==range(table(dfMain$family_member))[2]){
  print("amodal")
} else{
  print(paste("Moda:",DescTools::Mode(dfMain$family_member)))
}

mean(dfMain$family_member)#MEDIA

median(dfMain$family_member)#MEDIANA

#medidas de localizacao n�o central: Quantis (Quartis e Decis)

quantile(dfMain$family_member, c(0.25,0.50,0.75))#QUARTIS

quantile(dfMain$family_member, probs = seq(.1, .9, by = .1))#DECIS

# medidas de dispers�o: vari�ncia, desvio padr�o, amplitude total, amplitude interquartil 

var(dfMain$family_member) #VARI�NCIA

sd(dfMain$family_member) #DESVIO PADR�O

(A = max(dfMain$family_member)-min(dfMain$family_member))#AMPLITUDE TOTAL

(AIQ = IQR(dfMain$family_member))#AMPLITUDE INTERQUARTIL

skewness(dfMain$family_member,type=3)
##Assimetria Positica dado que b1>0 (0.6395767)

## Curtose

kurtosis(dfMain$family_member,type = 3)
##  curva platic�urtica, achatada dado que b2<0 (-0.2621798)

#######################################################################################
#######################################################################################

#             teste de independencia Qui-Quadrado family_member/year

#######################################################################################
#######################################################################################

